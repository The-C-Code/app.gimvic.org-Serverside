<?php
$mac = $_GET['mac_hash'];
$type = $_GET['type'];
$os =$_GET['os'];
$version = $_GET['version'];
$development = $_GET['development'];
$opened_offline = $_GET['opened_offline'];


if($development!=="true"){
	date_default_timezone_set("Europe/Ljubljana");
	$date = date('Y-m-d H:i:s');
	$file = 'database.txt';
	$current = file_get_contents($file);
	$current = 
		$current."\n".$date."|".$mac."|".$type."|".$os."|".$version."|".$opened_offline;
	file_put_contents($file, $current);
	}


?>
