<?php
$mac = $_GET['mac_hash'];
$os =$_GET['os'];
$osVersion = $_GET['osVersion'];
$appVersion = $_GET['appVersion'];

date_default_timezone_set("Europe/Ljubljana");
$date = date('Y-m-d H:i:s');
$file = 'database.txt';
$current = file_get_contents($file);
$current = $current."\n".$date."|".$mac."|".$os."|".$osVersion."|".$appVersion;
file_put_contents($file, $current);
?>
