<?php
	
//default_timezone_set('Europe/Ljubljana');
$server_name='solsis.gimvic.org';
$apikey = 'ede5e730-8464-11e3-baa7-0800200c9a66';
$url='https://'.$server_name.'/?';
$date='2014-01-30';
$nonsense=uniqid('jebanondelizdej',true);
$params='func=gateway&call=suplence&datum='.$date.'&nonsense='.$nonsense;
$signature_string = $server_name . '||' . $params . '||' . $apikey;
$signature = hash('sha256', $signature_string);
$url .= $params.'&signature='.$signature;
//$curl = curl_init();
//curl_setopt($curl, CURLOPT_URL, $url);
//curl_setopt($curl, //CURLOPT_RETURNTRANSFER, true);
//$json = curl_exec($curl);
//curl_close($curl);
//print_r(json_decode($json, true));
//echo ('URL: ', $url, "\n");
//echo $json;
echo $url;
//echo '\ntest';

?>
